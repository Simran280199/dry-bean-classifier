# 🫘 Dry Bean Classifier — Complete Guide (From Scratch)

## 📁 Final Project Structure

```
dry-bean-classifier/          ← your project folder
├── app.py                    ← Streamlit app  (trains model at runtime)
├── beans1.xlsx               ← Dataset        (REQUIRED)
├── requirements.txt          ← Dependencies
├── Beans_Classification.ipynb← Full notebook
├── .gitignore
└── README.md
```

> **No `models/` folder needed** — the app trains the model on startup
> and caches it. Works both locally and on Streamlit Cloud.

---

## 🖥️ PART A — LOCAL SETUP (VS Code)

### Step 1 — Create project folder

```bash
mkdir dry-bean-classifier
cd dry-bean-classifier
```

### Step 2 — Copy your files into this folder

Copy these files into `dry-bean-classifier/`:
- `app.py`
- `beans1.xlsx`
- `requirements.txt`
- `Beans_Classification.ipynb`
- `.gitignore`

### Step 3 — Create a virtual environment (recommended)

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac / Linux
python3 -m venv venv
source venv/bin/activate
```

### Step 4 — Install dependencies

```bash
pip install -r requirements.txt
```

### Step 5 — Run the Streamlit app

```bash
streamlit run app.py
```

Open your browser at: **http://localhost:8501**

> First launch trains the model (~15 seconds). After that it's instant.

### Step 6 — Open the Notebook (optional)

In VS Code: open `Beans_Classification.ipynb`
Select kernel → Python (your venv)
Run All Cells

---

## ☁️ PART B — STREAMLIT CLOUD DEPLOYMENT

### Step 1 — Create GitHub repository

Go to https://github.com → New Repository
- Name: `dry-bean-classifier`
- Visibility: **Public**
- Do NOT add README (you already have one)

### Step 2 — Initialize git and push

Run these commands inside your `dry-bean-classifier/` folder:

```bash
git init
git add .
git commit -m "Initial commit — Dry Bean Classifier"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/dry-bean-classifier.git
git push -u origin main
```

> Replace `YOUR_USERNAME` with your actual GitHub username.

### Step 3 — Deploy on Streamlit Cloud

1. Go to **https://share.streamlit.io**
2. Sign in with GitHub
3. Click **"New app"**
4. Select:
   - Repository: `YOUR_USERNAME/dry-bean-classifier`
   - Branch: `main`
   - Main file: `app.py`
5. Click **"Deploy!"**

### Step 4 — Wait for deployment

- Build takes 2–3 minutes
- First app load takes ~15–20 seconds (model trains)
- After that — instant for all users ✅

---

## 🔄 How to Update Your App Later

```bash
# Make changes to any file, then:
git add .
git commit -m "Update description"
git push
```

Streamlit Cloud auto-redeploys on every push.

---

## 🧠 Model Details

| Property | Value |
|----------|-------|
| Algorithm | HistGradientBoostingClassifier |
| Test Accuracy | **92.5 %** |
| Macro F1 Score | **0.94** |
| Train Accuracy | 96.8 % |
| Overfit Gap | 4.3 % (healthy) |
| Features used | 16 physical measurements |
| Classes | 7 (BARBUNYA, BOMBAY, CALI, DERMASON, HOROZ, SEKER, SIRA) |
| Class imbalance | Handled via `class_weight='balanced'` |
| Skewed features | 13 features log1p-transformed |

---

## ❓ Troubleshooting

| Problem | Fix |
|---------|-----|
| `beans1.xlsx not found` | Make sure `beans1.xlsx` is in the **same folder** as `app.py` |
| `ModuleNotFoundError` | Run `pip install -r requirements.txt` again |
| Streamlit Cloud error | Check that `beans1.xlsx` is committed to GitHub |
| Slow first load | Normal — model trains once (~15s), then cached |
| Port already in use | Run `streamlit run app.py --server.port 8502` |
